export const COMPANY = {
  name: "Amorim Engenharia & Pré Moldados",
  nameShort: "Amorim Engenharia",
  phoneDisplay: "(49) 991871923",
  phoneTel: "+5549991871923",
  whatsappLink: "https://wa.link/zpl56x",
  whatsappNumber: "5549991871923",
  address: "R. Santa Catarina, 1004, Catanduvas, SC 89670-000, Brasil",
  addressLines: ["R. Santa Catarina, 1004", "Catanduvas, SC 89670-000", "Brasil"],
  instagram: "https://instagram.com/luizhenriqueamorim_eng",
  hours: [
    { days: "Segunda a Sexta", hours: "9:00 – 22:00" },
    { days: "Sábado", hours: "9:00 – 18:00" },
    { days: "Domingo", hours: "9:00 – 12:00" },
  ],
  mapsEmbed:
    "https://www.google.com/maps?q=R.+Santa+Catarina,+1004,+Catanduvas,+SC+89670-000,+Brasil&output=embed",
  mapsLink:
    "https://www.google.com/maps/search/?api=1&query=R.+Santa+Catarina,+1004,+Catanduvas,+SC+89670-000",
  siteUrl: "https://amorimengenharia.com.br",
} as const;

export const NAV_LINKS = [
  { href: "#inicio", label: "Início" },
  { href: "#servicos", label: "Serviços" },
  { href: "#projetos", label: "Projetos" },
  { href: "#sobre", label: "Sobre" },
  { href: "#contato", label: "Contato" },
] as const;

export function buildWhatsAppUrl(message: string) {
  return `https://wa.me/${COMPANY.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
