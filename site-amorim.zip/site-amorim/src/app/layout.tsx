import type { Metadata } from "next";
import { Poppins } from "next/font/google";
import "./globals.css";
import { COMPANY } from "@/lib/constants";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-poppins",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(COMPANY.siteUrl),
  title: {
    default: "Amorim Engenharia & Pré Moldados | Catanduvas SC",
    template: "%s | Amorim Engenharia",
  },
  description:
    "Construtora e fábrica de pré-moldados em Catanduvas, SC. Casas pré-moldadas a partir de R$ 10.000, blocos de concreto, alvenaria, projetos de engenharia, BIM e entrega própria.",
  keywords: [
    "Amorim Engenharia",
    "pré-moldados Catanduvas",
    "fábrica de pré-moldados SC",
    "casas pré-moldadas",
    "construção civil Catanduvas",
    "blocos de concreto",
    "financiamento Caixa",
  ],
  authors: [{ name: COMPANY.name }],
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: COMPANY.siteUrl,
    siteName: COMPANY.name,
    title: "Amorim Engenharia & Pré Moldados | Catanduvas SC",
    description:
      "Engenharia, construção e pré-moldados com fábrica e entrega próprias em Catanduvas, SC. Solicite seu orçamento pelo WhatsApp.",
    images: [
      {
        url: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1200&q=80",
        width: 1200,
        height: 630,
        alt: "Amorim Engenharia — construção e pré-moldados",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Amorim Engenharia & Pré Moldados",
    description:
      "Casas pré-moldadas, alvenaria, blocos e projetos de engenharia em Catanduvas, SC.",
  },
  icons: { icon: "/favicon.svg" },
  robots: { index: true, follow: true },
  alternates: { canonical: COMPANY.siteUrl },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR" className={poppins.variable}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
