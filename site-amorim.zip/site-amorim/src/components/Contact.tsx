"use client";

import { FormEvent, useState } from "react";
import { COMPANY, buildWhatsAppUrl } from "@/lib/constants";

export function Contact() {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [telefone, setTelefone] = useState("");
  const [mensagem, setMensagem] = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const text = [
      "Olá! Gostaria de um orçamento / contato via site.",
      "",
      `Nome: ${nome.trim()}`,
      email.trim() ? `E-mail: ${email.trim()}` : null,
      telefone.trim() ? `Telefone: ${telefone.trim()}` : null,
      "",
      `Mensagem: ${mensagem.trim() || "(sem mensagem adicional)"}`,
    ]
      .filter((line) => line !== null)
      .join("\n");

    window.open(buildWhatsAppUrl(text), "_blank", "noopener,noreferrer");
  }

  return (
    <section id="contato" className="py-20 md:py-28 bg-forest-dark text-white relative overflow-hidden">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07] select-none flex items-center justify-center"
        aria-hidden
      >
        <p className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-center px-4">
          Estamos prontos para ajudar você!
        </p>
      </div>

      <div className="container-site relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          <div>
            <p className="section-label text-brand">Contato</p>
            <h2 className="mt-3 text-3xl md:text-4xl font-bold tracking-tight">
              Fale conosco
            </h2>
            <p className="mt-4 text-white/70 leading-relaxed max-w-lg">
              Preencha o formulário e abriremos o WhatsApp com sua mensagem pronta.
              Sem cadastro, sem espera — atendimento direto com a equipe Amorim.
            </p>

            <form onSubmit={handleSubmit} className="mt-8 space-y-4">
              <div>
                <label htmlFor="nome" className="block text-sm font-medium text-white/90 mb-1.5">
                  Nome <span className="text-red-400">*</span>
                </label>
                <input
                  id="nome"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full rounded-md border border-white/25 bg-transparent px-4 py-3 text-white placeholder:text-white/40 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-white/90 mb-1.5">
                  Endereço de e-mail
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  className="w-full rounded-md border border-white/25 bg-transparent px-4 py-3 text-white placeholder:text-white/40 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
                />
              </div>
              <div>
                <label htmlFor="telefone" className="block text-sm font-medium text-white/90 mb-1.5">
                  Telefone <span className="text-red-400">*</span>
                </label>
                <input
                  id="telefone"
                  required
                  value={telefone}
                  onChange={(e) => setTelefone(e.target.value)}
                  placeholder="(49) 99999-9999"
                  className="w-full rounded-md border border-white/25 bg-transparent px-4 py-3 text-white placeholder:text-white/40 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
                />
              </div>
              <div>
                <label htmlFor="mensagem" className="block text-sm font-medium text-white/90 mb-1.5">
                  Mensagem <span className="text-red-400">*</span>
                </label>
                <textarea
                  id="mensagem"
                  required
                  rows={4}
                  value={mensagem}
                  onChange={(e) => setMensagem(e.target.value)}
                  placeholder="Conte um pouco sobre o seu projeto"
                  className="w-full rounded-md border border-white/25 bg-transparent px-4 py-3 text-white placeholder:text-white/40 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand resize-y"
                />
              </div>
              <button type="submit" className="btn-brand w-full sm:w-auto min-w-[180px]">
                Enviar no WhatsApp
              </button>
            </form>
          </div>

          <div className="space-y-6">
            <div className="rounded-2xl overflow-hidden border border-white/10 shadow-xl aspect-[4/3] bg-forest">
              <iframe
                title="Localização Amorim Engenharia — Catanduvas SC"
                src={COMPANY.mapsEmbed}
                className="h-full w-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-6 space-y-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand">WhatsApp e Tel</p>
                <a
                  href={COMPANY.whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 inline-block text-lg font-semibold hover:text-brand transition"
                >
                  {COMPANY.phoneDisplay}
                </a>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand">Endereço</p>
                <a
                  href={COMPANY.mapsLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 block text-white/85 hover:text-white underline-offset-2 hover:underline leading-relaxed"
                >
                  {COMPANY.address}
                </a>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand">Horário</p>
                <ul className="mt-2 space-y-1 text-sm text-white/80">
                  {COMPANY.hours.map((h) => (
                    <li key={h.days} className="flex justify-between gap-4">
                      <span>{h.days}</span>
                      <span className="font-medium text-white">{h.hours}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand">Instagram</p>
                <a
                  href={COMPANY.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 inline-block text-white/85 hover:text-brand transition"
                >
                  @luizhenriqueamorim_eng
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
