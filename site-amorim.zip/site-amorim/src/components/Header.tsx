"use client";

import { useEffect, useState } from "react";
import { COMPANY, NAV_LINKS } from "@/lib/constants";

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const headerShadow = scrolled ? "shadow-lg shadow-black/20" : "";

  return (
    <header className={"fixed inset-x-0 top-0 z-50 transition-shadow " + headerShadow}>
      <div className="bg-forest-dark/95 backdrop-blur-md border-b border-white/5">
        <div className="container-site flex items-center justify-between gap-4 py-3 md:py-4">
          <a href="#inicio" className="min-w-0 group">
            <p className="text-[11px] sm:text-xs md:text-sm font-bold uppercase tracking-[0.12em] text-white leading-tight group-hover:text-brand transition">
              Amorim Engenharia &amp; Pré Moldados
            </p>
            <p className="mt-0.5 text-[11px] text-white/70 underline-offset-2 group-hover:underline">
              WhatsApp e Tel: {COMPANY.phoneDisplay}
            </p>
          </a>

          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-3 py-2 text-sm font-medium text-white/85 hover:text-white hover:bg-white/5 rounded-md transition"
              >
                {link.label}
              </a>
            ))}
            <a
              href={COMPANY.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="ml-2 btn-brand !py-2.5 !px-4 !text-xs"
            >
              WhatsApp
            </a>
          </nav>

          <button
            type="button"
            className="lg:hidden inline-flex items-center justify-center rounded-md p-2 text-white hover:bg-white/10"
            aria-label={open ? "Fechar menu" : "Abrir menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? (
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-forest-dark border-b border-white/10">
          <nav className="container-site flex flex-col py-3 gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="px-3 py-3 text-base font-medium text-white/90 hover:bg-white/5 rounded-md"
              >
                {link.label}
              </a>
            ))}
            <a
              href={COMPANY.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="btn-brand mt-2 mx-3 mb-2"
            >
              Falar no WhatsApp
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
