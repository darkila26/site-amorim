import { COMPANY } from "@/lib/constants";

export function WhatsAppFloat() {
  return (
    <a
      href={COMPANY.whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Abrir WhatsApp"
      className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-black/25 transition hover:scale-105 hover:bg-[#20bd5a] focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
    >
      <svg viewBox="0 0 32 32" className="h-7 w-7 fill-current" aria-hidden>
        <path d="M16.01 3C9.39 3 4 8.39 4 15.01c0 2.11.55 4.09 1.52 5.81L4 29l8.39-1.48A11.95 11.95 0 0016.01 27C22.63 27 28 21.61 28 15.01 28 8.39 22.63 3 16.01 3zm0 21.82c-1.86 0-3.6-.5-5.1-1.37l-.36-.21-4.98.88.9-4.85-.24-.39a9.73 9.73 0 01-1.48-5.17c0-5.39 4.39-9.77 9.78-9.77 5.39 0 9.77 4.38 9.77 9.77 0 5.39-4.38 9.78-9.77 9.78zm5.36-7.32c-.29-.15-1.73-.85-2-.95-.27-.1-.46-.15-.66.15-.19.29-.76.95-.93 1.14-.17.2-.34.22-.63.07-.29-.15-1.22-.45-2.32-1.43-.86-.76-1.44-1.71-1.61-2-.17-.29-.02-.45.13-.59.13-.13.29-.34.44-.51.15-.17.19-.29.29-.49.1-.2.05-.37-.02-.52-.07-.15-.66-1.59-.9-2.18-.24-.58-.48-.5-.66-.51h-.56c-.2 0-.51.07-.78.37-.27.29-1.02.99-1.02 2.42s1.05 2.81 1.19 3c.15.2 2.06 3.15 5 4.42.7.3 1.24.48 1.67.61.7.22 1.34.19 1.85.12.56-.08 1.73-.71 1.97-1.39.24-.68.24-1.27.17-1.39-.07-.12-.26-.2-.55-.34z" />
      </svg>
    </a>
  );
}
