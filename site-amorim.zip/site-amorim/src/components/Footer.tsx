import { COMPANY, NAV_LINKS } from "@/lib/constants";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-forest-dark border-t border-white/10 text-white">
      <div className="container-site py-12 md:py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <p className="text-sm font-bold uppercase tracking-[0.14em]">
              Amorim Engenharia &amp; Pré Moldados
            </p>
            <p className="mt-3 text-sm text-white/65 max-w-md leading-relaxed">
              Engenharia, construção e fábrica de pré-moldados em Catanduvas, SC — com equipe e
              entrega próprias.
            </p>
            <a
              href={COMPANY.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-brand mt-6 !text-xs"
            >
              Agendar consulta
            </a>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-brand">Navegação</p>
            <ul className="mt-4 space-y-2">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-sm text-white/75 hover:text-white transition">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-brand">Localização</p>
            <a
              href={COMPANY.mapsLink}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 block text-sm text-white/75 hover:text-white underline-offset-2 hover:underline leading-relaxed"
            >
              {COMPANY.addressLines.map((line) => (
                <span key={line} className="block">
                  {line}
                </span>
              ))}
            </a>
            <a
              href={COMPANY.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-block text-sm text-white/75 hover:text-brand transition"
            >
              Instagram
            </a>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between text-xs text-white/45">
          <p>
            © {year} {COMPANY.name}. Todos os direitos reservados.
          </p>
          <p>Catanduvas — Santa Catarina</p>
        </div>
      </div>
    </footer>
  );
}
