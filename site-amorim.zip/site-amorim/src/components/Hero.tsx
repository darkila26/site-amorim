export function Hero() {
  return (
    <section id="inicio" className="relative min-h-[88vh] flex items-center pt-24">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            "url(https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=1920&q=80)",
        }}
        aria-hidden
      />
      <div className="absolute inset-0 bg-gradient-to-b from-forest-dark/80 via-forest/70 to-forest-dark/90" />

      <div className="container-site relative z-10 py-20 md:py-28 text-center">
        <p className="section-label text-brand mb-4 drop-shadow">Soluções em construção</p>
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white tracking-tight text-balance max-w-4xl mx-auto">
          Engenharia e pré-moldados para o seu projeto
        </h1>
        <p className="mt-5 text-base md:text-lg text-white/85 max-w-2xl mx-auto leading-relaxed">
          Fábrica própria de blocos e pré-moldados, equipe especializada e entrega com frota própria
          em Catanduvas e região.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3">
          <a href="#servicos" className="btn-brand min-w-[200px]">
            Ver serviços
          </a>
          <a href="#contato" className="btn-outline-light min-w-[200px]">
            Solicitar orçamento
          </a>
        </div>
      </div>
    </section>
  );
}
