import { COMPANY } from "@/lib/constants";

const DIFFERENTIALS = [
  {
    title: "Sustentabilidade",
    description:
      "Produzimos blocos com responsabilidade ambiental, reduzindo resíduos e utilizando práticas ecoeficientes em toda a cadeia de produção.",
    icon: "leaf",
  },
  {
    title: "Preço competitivo",
    description:
      "Oferecemos qualidade com economia real. Soluções sob medida com custo-benefício transparente e sem surpresas.",
    icon: "tag",
  },
  {
    title: "Entrega própria",
    description:
      "Possuímos frota própria e todos os equipamentos necessários para realizar as entregas com pontualidade e segurança.",
    icon: "truck",
  },
  {
    title: "Equipe própria",
    description:
      "Profissionais qualificados e comprometidos em cada etapa — da fábrica ao canteiro — para garantir qualidade e controle total.",
    icon: "users",
  },
];

function Icon({ name }: { name: string }) {
  const common = "h-6 w-6 text-brand";
  if (name === "leaf") {
    return (
      <svg className={common} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 22c4-4 7-7.5 7-12a7 7 0 10-14 0c0 4.5 3 8 7 12z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 22V10" />
      </svg>
    );
  }
  if (name === "tag") {
    return (
      <svg className={common} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" />
        <circle cx="7.5" cy="7.5" r="1.5" fill="currentColor" />
      </svg>
    );
  }
  if (name === "truck") {
    return (
      <svg className={common} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M1 3h15v13H1zM16 8h4l3 3v5h-7V8z" />
        <circle cx="5.5" cy="18.5" r="2.5" />
        <circle cx="18.5" cy="18.5" r="2.5" />
      </svg>
    );
  }
  return (
    <svg className={common} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
    </svg>
  );
}

export function About() {
  return (
    <section id="sobre" className="py-20 md:py-28 bg-white">
      <div className="container-site">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <p className="section-label">Sobre nós</p>
            <h2 className="section-title mt-3">Amorim Engenharia &amp; Pré Moldados</h2>
            <div className="mt-5 space-y-4 text-forest/75 leading-relaxed">
              <p>
                A <strong className="text-forest">Amorim Engenharia e Pré-Moldados</strong> é uma
                empresa de engenharia em Santa Catarina, localizada em Catanduvas, que atua no setor
                de <strong className="text-forest">construção civil e pré-moldados</strong>. Com foco
                em qualidade e inovação, somos uma construtora especializada na fabricação de{" "}
                <strong className="text-forest">blocos pré-moldados</strong>, construção de casas e
                desenvolvimento de projetos de engenharia sob medida.
              </p>
              <p>
                Nossa trajetória é marcada pelo compromisso com a excelência e pela confiança de
                nossos clientes, tornando-nos uma referência local como{" "}
                <strong className="text-forest">fábrica de pré-moldados SC</strong> que entrega
                soluções completas em engenharia e construção.
              </p>
              <p>
                Para garantir qualidade, agilidade e controle total sobre cada etapa, possuímos{" "}
                <strong className="text-forest">frota própria</strong> e{" "}
                <strong className="text-forest">todos os equipamentos</strong> necessários para
                realizar as entregas com pontualidade e segurança — em projetos residenciais,
                comerciais ou industriais.
              </p>
            </div>
            <a
              href={COMPANY.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-brand mt-8"
            >
              WhatsApp
            </a>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-2xl shadow-card aspect-[4/5] md:aspect-[5/6]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=900&q=80"
                alt="Equipe de engenharia e construção Amorim"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute -bottom-6 -left-4 md:-left-8 bg-forest-dark text-white rounded-xl p-5 shadow-xl max-w-[240px]">
              <p className="text-brand text-xs font-bold uppercase tracking-wider">Fábrica própria</p>
              <p className="mt-1 text-sm font-medium leading-snug">
                Pré-moldados + entrega própria em Catanduvas e região
              </p>
            </div>
          </div>
        </div>

        <div className="mt-24">
          <p className="section-label">Sobre nós</p>
          <h2 className="section-title mt-3">Nossos diferenciais</h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {DIFFERENTIALS.map((item) => (
              <div
                key={item.title}
                className="rounded-2xl border border-forest/8 bg-stone-50 p-6 hover:border-brand/30 hover:bg-brand-soft/40 transition"
              >
                <div className="h-12 w-12 rounded-xl bg-white border border-forest/8 flex items-center justify-center shadow-sm">
                  <Icon name={item.icon} />
                </div>
                <h3 className="mt-4 text-lg font-bold text-forest">{item.title}</h3>
                <p className="mt-2 text-sm text-forest/65 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
