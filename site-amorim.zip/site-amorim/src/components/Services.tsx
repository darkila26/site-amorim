const SERVICES = [
  {
    title: "Financiamento pela Caixa",
    description:
      "Orientação completa para financiar sua obra ou imóvel com as linhas da Caixa Econômica Federal.",
    image:
      "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Casas Pré-Moldadas",
    description:
      "Casas pré-moldadas a partir de R$ 10.000, com agilidade, qualidade e personalização do projeto.",
    image:
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Construção de Alvenaria",
    description:
      "Construção tradicional em alvenaria com acompanhamento técnico e acabamento profissional.",
    image:
      "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Blocos de concreto",
    description:
      "Produção própria de blocos de concreto com padrão industrial e fornecimento contínuo.",
    image:
      "https://images.unsplash.com/photo-1590496793929-36417d95d441?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Projetos elétricos, hidrossanitários e estruturais",
    description:
      "Projetos técnicos completos para garantir segurança, eficiência e conformidade normativa.",
    image:
      "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "BIM & Gerenciamento",
    description:
      "Modelagem BIM e gestão de obra para mais previsibilidade, controle de custos e prazos.",
    image:
      "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Decoração de interiores",
    description:
      "Projetos de interiores que valorizam o espaço, o conforto e a identidade do seu imóvel.",
    image:
      "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Lajes convencionais e treliçadas",
    description:
      "Execução e fornecimento de lajes convencionais e treliçadas com suporte técnico especializado.",
    image:
      "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Barracão de estrutura metálica",
    description:
      "Projetos e montagem de barracões metálicos para uso comercial, industrial e agropecuário.",
    image:
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80",
  },
];

export function Services() {
  return (
    <section id="servicos" className="py-20 md:py-28 bg-white">
      <div className="container-site">
        <div className="max-w-2xl">
          <p className="section-label">Nossos serviços</p>
          <h2 className="section-title mt-3">
            Soluções em engenharia e pré-moldados
          </h2>
          <p className="mt-4 text-forest/70 text-base md:text-lg leading-relaxed">
            Projetos personalizados para sua necessidade — da fábrica à entrega, com equipe própria
            e acompanhamento de ponta a ponta.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service) => (
            <article
              key={service.title}
              className="group overflow-hidden rounded-2xl bg-white border border-forest/8 shadow-card hover:-translate-y-1 hover:shadow-xl transition duration-300"
            >
              <div className="aspect-[16/10] overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={service.image}
                  alt={service.title}
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="p-5 md:p-6">
                <h3 className="text-lg font-bold text-forest leading-snug">
                  {service.title}
                </h3>
                <p className="mt-2 text-sm text-forest/65 leading-relaxed">
                  {service.description}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
