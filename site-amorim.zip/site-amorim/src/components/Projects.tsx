"use client";

import { useState } from "react";

const PROJECTS = [
  {
    title: "Residência contemporânea",
    location: "Catanduvas, SC",
    image:
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1400&q=80",
  },
  {
    title: "Casa pré-moldada",
    location: "Oeste Catarinense",
    image:
      "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1400&q=80",
  },
  {
    title: "Obra em alvenaria",
    location: "Santa Catarina",
    image:
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=80",
  },
  {
    title: "Estrutura e acabamento",
    location: "Catanduvas e região",
    image:
      "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1400&q=80",
  },
];

export function Projects() {
  const [index, setIndex] = useState(0);
  const current = PROJECTS[index];

  const prev = () => setIndex((i) => (i === 0 ? PROJECTS.length - 1 : i - 1));
  const next = () => setIndex((i) => (i === PROJECTS.length - 1 ? 0 : i + 1));

  return (
    <section id="projetos" className="py-20 md:py-28 bg-stone-50">
      <div className="container-site">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <p className="section-label">Portfólio</p>
            <h2 className="section-title mt-3">Projetos realizados</h2>
            <p className="mt-3 text-forest/70 max-w-xl">
              Conheça alguns dos projetos que entregamos com qualidade, prazo e
              acompanhamento técnico.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={prev}
              aria-label="Projeto anterior"
              className="h-11 w-11 rounded-full border border-forest/15 bg-white text-forest hover:bg-brand hover:text-white hover:border-brand transition"
            >
              ‹
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Próximo projeto"
              className="h-11 w-11 rounded-full border border-forest/15 bg-white text-forest hover:bg-brand hover:text-white hover:border-brand transition"
            >
              ›
            </button>
          </div>
        </div>

        <div className="mt-10 relative overflow-hidden rounded-2xl shadow-card bg-forest-dark">
          <div className="aspect-[16/9] md:aspect-[21/9] relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              key={current.image}
              src={current.image}
              alt={current.title}
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-forest-dark/90 via-forest-dark/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
              <p className="text-brand text-xs font-semibold uppercase tracking-widest">
                {current.location}
              </p>
              <h3 className="mt-1 text-2xl md:text-3xl font-bold text-white">
                {current.title}
              </h3>
              <p className="mt-2 text-white/70 text-sm">
                {index + 1} / {PROJECTS.length}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-4 flex justify-center gap-2">
          {PROJECTS.map((p, i) => (
            <button
              key={p.title}
              type="button"
              aria-label={`Ir para ${p.title}`}
              onClick={() => setIndex(i)}
              className={
                "h-2.5 rounded-full transition-all " +
                (i === index ? "w-8 bg-brand" : "w-2.5 bg-forest/20 hover:bg-forest/40")
              }
            />
          ))}
        </div>
      </div>
    </section>
  );
}
